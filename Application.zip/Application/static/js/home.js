$(function(){
	$('input[type="radio"]').click(function(){
		$.ajax({
			url: '/home',
			data: $('form').serialize(),
			type: 'POST',
			success: function(response){
				var $result = $(response).find('#imageId');
				var $imgPath = $result.attr("src")
				$(imageId).attr('src',$imgPath)

				var $result = $(response).find('#textId');
				var $imgPath = $result.attr("src")
				$(textId).attr('src',$imgPath)

				var $result = $(response).find('#audioId');
				var $audioPath = $result.attr("src")
				$(audioId).attr('src',$audioPath)

				$("input:checked").removeAttr("checked");
			},
			error: function(error){
				console.log(error);
			}
		});
	});

	$('#languageId').change(function(){
		$.ajax({
			url: '/home',
			data: $('form').serialize(),
			type: 'GET',
			success: function(response){
				var $result = $(response).find('#imageId');
				var $imgPath = $result.attr("src")
				$(imageId).attr('src',$imgPath)

				var $result = $(response).find('#textId');
				var $imgPath = $result.attr("src")
				$(textId).attr('src',$imgPath)
			},
			error: function(error){
				console.log(error);
			}
		});
	});
});
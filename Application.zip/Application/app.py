from flask import Flask, render_template, redirect, url_for, request
from Functions import *

#Global
app = Flask(__name__)

User_id = ""
Image_id = ""
Text_id = ""
Audio_id = ""
Language_id = "English"


@app.route("/", methods=['GET', 'POST'])
def login():
    """Login Page"""
    error = None
    global User_id
    global Image_id
    global Text_id
    global Audio_id

    if request.method == 'POST':
        username = request.form['username']
        authenticate = authenticate_user(username, request.form['password'])
        if authenticate:
            User_id = username
            Image_id = ""
            Text_id = ""
            Audio_id = ""
            return redirect(url_for('image_page'))
        else:
            error = 'Invalid Credentials. Please try again.'

    return render_template('login.html', error=error)


@app.route("/home", methods=['GET', 'POST'])
def image_page():
    """Home Page showing Image"""
    error = None
    global Image_id
    global Text_id
    global Audio_id
    global Language_id

    imageFile = Image_id
    textfile = Text_id
    audioFile = Audio_id

    if request.method == 'POST':
        languageId = request.form.get('languageId')
        selection = request.form.get('category')
        write_to_file(User_id, str(Image_id), str(Audio_id), str(languageId), str(selection))
        imageFile, textfile, audioFile = fetch_files(languageId)
        Image_id = imageFile
        Text_id = textfile
        Audio_id = audioFile
        return render_template('home.html', image=imageFile, text=textfile, audio=audioFile, error=error)

    # Redirect to Login screen if user id is not available
    if not User_id:
        return redirect(url_for('login'))

    # Fetch image when the page is loaded first time
    if not Image_id:
        imageFile, textfile, audioFile = fetch_files()
        Image_id = imageFile
        Text_id = textfile
        Audio_id = audioFile

    # Fetch different image when the language changes
    current_languageid = request.args.get('languageId')
    if (current_languageid is not None) and current_languageid != Language_id:
        Language_id = current_languageid
        imageFile, textfile, audioFile = fetch_files(Language_id)
        Image_id = imageFile
        Text_id = textfile
        Audio_id = audioFile

    return render_template('home.html', image=imageFile, text=textfile, audio=audioFile, error=error)


if __name__ == "__main__":
    app.run()

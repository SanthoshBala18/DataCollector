Go into virtual\Scripts in cmd and run "activate virtual"
Navigate back to "Application" folder
Run "python app.py"
Copy "http://127.0.0.1:5000/" in the browser, Application will run locally
import gspread
from oauth2client.service_account import ServiceAccountCredentials
from datetime import datetime
import time
import random
import re
import os
import sys
import logging as log

imageFiles = []
textFiles = []
audioFiles = []

opened_Files = {}


def authenticate_user(username, password):
    """Function to authenticate User"""
    global opened_Files
    global imageFiles
    global textFiles
    global audioFiles
    with open("UserDetails.txt", "r") as f:
        for line in f:
            db_username, db_password = line.split(",")
            if (db_username.strip() == username) and (db_password.strip() == password):
                imageFiles = os.listdir(".//static//Images")
                textFiles = os.listdir(".//static//TextImages")
                audioFiles = os.listdir(".//static//Audios")
                opened_Files = {}
                return True
        else:
            return False


def write_to_file(userId="", imageId="", audioId="", languageId="", selection=""):
    """Function to write the data to CSV
    """
    try:
        ts = time.time()
        timestamp = datetime.fromtimestamp(ts).strftime('%Y-%m-%d %H:%M:%S')

        line = [str(timestamp), userId, imageId, audioId, languageId, selection]

        scope = ["https://spreadsheets.google.com/feeds/", "https://www.googleapis.com/auth/drive"]
        credentials = ServiceAccountCredentials.from_json_keyfile_name("Datacollector-a47184d1c4bb.json", scope)
        gs = gspread.authorize(credentials)

        titles_list = []
        sheet = "Check"
        for spreadsheet in gs.openall():
            titles_list.append(spreadsheet.title)

        if sheet not in titles_list:
            sh = gs.create(sheet)
            sh.share('santhoshbala0718@gmail.com', perm_type='user', role='owner')

        wks = gs.open(sheet).sheet1
        wks.append_row(line)
    except:
        e = sys.exc_info()
        log.error(e)


def fetch_files(languageId = "English"):
    """Function to fetch random Images,Image Text and audio"""
    imageName = ""
    textName = ""
    audioName = ""

    global opened_Files
    global imageFiles
    global textFiles
    global audioFiles

    if not opened_Files:
        # If this is the first fetch
        imageName = random.choice(imageFiles)
        name, format = imageName.split(".")
        reg = re.compile(r'^' + name)
        audios_for_image = list(filter(reg.match, audioFiles))
        audioName = random.choice(audios_for_image)
        textName  = name+"_"+languageId+"."+format
        opened_Files.setdefault(imageName, []).append(audioName)
    else:
        counter = 0
        while True:
            if counter == 100:
                break
            imageName = random.choice(imageFiles)
            name, format = imageName.split(".")
            reg = re.compile(r'^' + name)
            textName = name+"_"+languageId+"."+format
            if imageName in opened_Files.keys():
                # If the chosen image is already displayed, check for a different voice
                opened_audios = opened_Files[imageName]
                audios_for_image = list(filter(reg.match, audioFiles))
                audios_available = list(set(audios_for_image)-set(opened_audios))
                if audios_available:
                    audioName = random.choice(audios_available)
                    opened_Files.setdefault(imageName, []).append(audioName)
                    break
            else:
                # If the chosen image is not already displayed, chose a random voice
                audios_for_image = list(filter(reg.match, audioFiles))
                audioName = random.choice(audios_for_image)
                opened_Files.setdefault(imageName, []).append(audioName)
                break
            counter += 1

    # Keep Default
    if (not imageName) or (not audioName) or (not textName):
        imageName = random.choice(imageFiles)
        name, format = imageName.split(".")
        reg = re.compile(r'^' + name)
        audios_for_image = list(filter(reg.match, audioFiles))
        audioName = random.choice(audios_for_image)
        textName = name + "_" + languageId + "." + format

    return imageName, textName, audioName

